# Resources

## Postman Collections

Below is the list of postman collections.

- [Open Banking - Build-55.postman_collection.json](/assets/postman/Build-55.postman_collection.json)
